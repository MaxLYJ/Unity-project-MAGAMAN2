﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnapToGrid : MonoBehaviour 
{
   public float snapX = .5f;
   public float snapY = .5f;
   public float offsetX = 0.0f; 
   public float offsetY = 0.0f; 
}
