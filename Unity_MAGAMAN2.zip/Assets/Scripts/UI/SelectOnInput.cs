﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class SelectOnInput : MonoBehaviour {
    public EventSystem eventSystem;
    public GameObject selectedObject;

    private bool buttonSelected;
    // Use this for initialization

    bool selected = false;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Input.GetAxisRaw("Vertical") != 0 && !selected)
        {
            eventSystem.SetSelectedGameObject(selectedObject);
            selected = true;
        }
	}

    private void OnDisable()
    {
        selected = false;
    }
}
