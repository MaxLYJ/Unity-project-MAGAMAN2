﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Healthbar : MonoBehaviour {
    public Slider slider;
    private Health playerHealth;
    private Health playerMaxHealth;
    // Use this for initialization
    void Start () {
        slider = GetComponent<Slider>();
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        playerHealth = player.GetComponent<Health>();
        playerMaxHealth = player.GetComponent<Health>();
        RectTransform sliderRect = GetComponent<RectTransform>();
        sliderRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, playerMaxHealth.maxHealth * 2.0f);
    }
	
	// Update is called once per frame
	void Update () {
        slider.value = playerHealth.health / playerMaxHealth.maxHealth;
	}

}
