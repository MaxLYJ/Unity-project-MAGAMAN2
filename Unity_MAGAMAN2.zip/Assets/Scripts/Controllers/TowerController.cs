﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerController : MonoBehaviour {
    public LayerMask enemyMask;
    public float speed = 1f;
    private float curspeed;
    Rigidbody2D myBody;
    Transform myTrans;
    float myWidth, myHeight;
    public Bounds bounds;
    private float delayTime = 2f;

	// Use this for initialization
	void Start () {
        GetComponentInChildren<SpriteRenderer>().flipX = false;
        myTrans = this.transform;
        myBody = this.GetComponent<Rigidbody2D>();
        myWidth = this.GetComponent<SpriteRenderer>().bounds.extents.x;
        myHeight = this.GetComponent<SpriteRenderer>().bounds.extents.y;
        curspeed = speed;

    }

    // Update is called once per frame
    void FixedUpdate ()
    {

        SpriteRenderer sr = GetComponentInChildren<SpriteRenderer>();
        BoxCollider2D cld = GetComponentInChildren<BoxCollider2D>();

        //Debug.Log(sr.flipX);

        Vector2 lineCastPos = myTrans.position - myTrans.right * myWidth;

        Vector2 lineCastPosRight = myTrans.position + myTrans.right * myWidth;


        Debug.DrawLine(lineCastPos + myTrans.up.toVector2() * myHeight,
            lineCastPos - myTrans.right.toVector2() * 0.25f + myTrans.up.toVector2() * myHeight * 0.3f);

        Debug.DrawLine(lineCastPosRight + myTrans.up.toVector2() * myHeight,
            lineCastPosRight + myTrans.right.toVector2() * 0.25f + myTrans.up.toVector2() * myHeight * 0.3f);

        //RaycastHit2D hit = Physics2D.Linecast(lineCastPos, lineCastPos + Vector2.down, enemyMask);
        //Debug.Log(hit.collider.name);

       // bool isGroundedLeft = Physics2D.Linecast(lineCastPos, lineCastPos + Vector2.down, enemyMask);

      //  bool isGroundedRight = Physics2D.Linecast(lineCastPosRight, lineCastPosRight + Vector2.down, enemyMask);

        bool isBlockedRight = Physics2D.Linecast(lineCastPosRight + myTrans.up.toVector2() * myHeight,
            lineCastPosRight + myTrans.right.toVector2() * 0.25f + myTrans.up.toVector2() * myHeight * 0.3f, enemyMask);

        bool isBlockedLeft = Physics2D.Linecast(lineCastPos + myTrans.up.toVector2() * myHeight,
            lineCastPos - myTrans.right.toVector2() * 0.25f + myTrans.up.toVector2() * myHeight * 0.3f, enemyMask);


      //  Debug.DrawLine(lineCastPosRight + myTrans.right.toVector2() * 10f + myTrans.up.toVector2() * myHeight * 0.5f,
       //     lineCastPos - myTrans.right.toVector2() * 10f + myTrans.up.toVector2() * myHeight * 0.5f);

        if (isBlockedLeft)
        {
         //   Debug.Log("left block");
         //   Debug.Log("<<" + sr.flipX);
            curspeed = speed;
            sr.flipX = false;
          //  Debug.Log(">>" + sr.flipX);
        }
        else if ( isBlockedRight)
        {
         //   Debug.Log("right block");
          //  Debug.Log("<<" + sr.flipX);
            curspeed = -speed;
            sr.flipX = true;
         //   Debug.Log(">>" + sr.flipX);
        }

        transform.Translate(new Vector3(curspeed * Time.deltaTime, 0, 0));

    }

}
