﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class AnimationEndCallback : MonoBehaviour {

    public UnityEvent Callbacks;

    public void OnAnimationEnd()
    {
        Debug.Log("Callback invoked");
        Callbacks.Invoke();
    }
}
