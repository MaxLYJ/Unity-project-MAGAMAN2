
Final: Wrapup
======

## Description
This will cover a little bit of everything covered in class.  A few new scenes & UIs, transitions, sequences, and the final boss enemy.  Should be completed by the end of the time given for the final.  You can start anytime.  

If you finsh before Final day - you still have to attend class per SMU policy, but may leave early once evals and attendance has been taken. 


## Tasks
[X] Lives & Game Over Screen
    [X] Add "Lives" to the GameController.  
    [X] Upon dying, remove one life.
    [X] If all lives are lost.  Transition to a GameOver screen which then transitions to the Level Select (resetting lives to 3, and resetting e-tank count to 0)
    [X] Otherwise, restart the level as normal.
[X] E-Tanks
    [X] Picking up an e-tank should add to your e-tank counter on the Game Controller.  Max of 4 (configurable in GameController)
[ ] Add a pause screen
    [X] Add a key mapping for "START" that is either the start button on the controller, or "ENTER" on the keyboard.
    [X] When player presses "START", pause the game, and open a pause screen.
    [X] Pause scren should display live count and e-tank count.
    [X] Should have 3 options - Resume (default), Use E-Tank, and Return to Level Select
    [X] Using an e-tank should remove an e-tank, unpause, and heal the player to full (can probably use same code you used for health pickups)
        [X] Do not allow this to be used if the player is already at full health.
        [X] Do not allow this to be used if player has no e-tanks. 
[ ] Metal Man
    [ x] Boss does not begin moving until visible by Megaman
    [ x] Implement Metal Man's behaviour (see video from previous assignment)
[ ] End Sequence
    [x ] A few seconds after boss is destroyed, control is removed from the player.
    [ x] A few seconds later - load into main menu; 